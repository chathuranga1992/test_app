package com.example.sample_log_app.ui;

import android.os.Bundle;

import com.example.sample_log_app.GenericActivity;
import com.example.sample_log_app.R;

public class MainActivity extends GenericActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}