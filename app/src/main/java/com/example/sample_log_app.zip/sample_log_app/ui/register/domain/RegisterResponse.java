package com.example.sample_log_app.ui.register.domain;


import com.example.sample_log_app.GenericEntity;
import com.example.sample_log_app.data.rest.domain.Image;

public class RegisterResponse extends GenericEntity {
    boolean enabled;
    Image image;
    String _id;

}
