package com.example.sample_log_app.ui.forgetpassword.domain;


import com.example.sample_log_app.GenericEntity;

public class ForgotPasswordResponse extends GenericEntity {
}
